# Time of Concentration Calculator - SCS/NRCS Method
## Project Handoff Documentation

**Date:** January 2025  
**Project:** Standalone TC Calculator for QGIS  
**Location:** E:\CLAUDE_Workspace\Claude\Report_Files\Codebase\Hydro_Suite\TC_NRCS_Stand_Alone  
**Purpose:** Create a working Time of Concentration calculator using the SCS/NRCS method for multiple subbasins

---

## 🎯 Primary Objective

Create a **standalone QGIS Python tool** that calculates Time of Concentration (TC) for multiple subbasins using the **SCS/NRCS TR-55 method** with actual Curve Number (CN) values from a shapefile field and elevation/slope data from a DEM raster.

---

## 📋 Requirements

### Functional Requirements

1. **Calculate TC for multiple subbasins** in a single run
2. **Use the SCS/NRCS TR-55 method** with proper formulas
3. **Read CN values from shapefile field** (CN_Comp)
4. **Extract slope from DEM raster** along flow paths
5. **Export results** to CSV and shapefile
6. **Full GUI** with layer and field selection
7. **No hardcoded paths** - all inputs selectable via GUI
8. **Work with both vector (subbasins) and raster (DEM) layers**

### Technical Requirements

- **Platform:** QGIS 3.40+ Python Console
- **Dependencies:** PyQt5, QGIS Python API, processing toolbox
- **Input Data:**
  - Subbasin shapefile with CN values
  - DEM raster layer for slope calculations
- **Output:** CSV and shapefile with TC results

---

## 📁 Known Data Locations

**Example Basin File:**  
`C:/JBC/Bragg Consulting/JBC - Share/Projects/001047-04/Production/GIS/Shapefiles/Hydrology/subbasins_cn.shp`

**Key Fields:**
- `CN_Comp` - Composite Curve Number values for each subbasin
- Basin ID field (user selectable)
- Area field (if available)

---

## 🚫 Current Issues with Existing Code

### Issue 1: DEM Layer Selection Problem
**Problem:** The original Hydro_Suite TC Calculator uses `LayerFieldSelector` widget which only shows vector layers, not raster layers.  
**Impact:** Users cannot select DEM raster layers in the GUI.  
**Solution Needed:** Create a proper raster layer selector widget that shows all raster layers in the project.

### Issue 2: Simplified Slope Calculation
**Problem:** Current code estimates slope using bounding box dimensions rather than actual DEM analysis.  
**Impact:** Inaccurate slope values leading to incorrect TC calculations.  
**Solution Needed:** Implement proper DEM sampling along flow paths or use zonal statistics.

### Issue 3: Incorrect SCS Formula Implementation
**Problem:** The SCS/NRCS formula in existing code is oversimplified and doesn't follow TR-55 guidelines.  
**Impact:** TC values don't match expected results from standard SCS calculations.  
**Solution Needed:** Implement correct SCS lag equation and TC formula per TR-55 documentation.

### Issue 4: Module Import Conflicts
**Problem:** Complex module loading in Hydro_Suite causes import errors and requires patching.  
**Impact:** Tool doesn't work out of the box, requires manual fixes.  
**Solution Needed:** Single standalone script with all necessary components included.

### Issue 5: Missing Flow Path Analysis
**Problem:** No actual flow path determination - just uses bounding box dimensions.  
**Impact:** Flow length is inaccurate, affecting TC calculations.  
**Solution Needed:** Either implement flow accumulation analysis or provide option for user to input flow length field.

---

## ✅ What Needs to Be Built

### 1. Main GUI Window
- **Layer Selection Section**
  - Dropdown for polygon layers (subbasins)
  - Dropdown for raster layers (DEM) - **MUST show raster layers**
  - Field selector for Basin ID
  - Field selector for CN values (auto-detect CN_Comp)
  - Optional: Field selector for flow length (if pre-calculated)

### 2. Parameter Input Section
- **Required Parameters:**
  - None if using field values
- **Optional Parameters:**
  - Default CN value (if field value missing)
  - Minimum slope threshold (default 0.5%)
  - Flow path method (longest path, centroid to outlet, field value)

### 3. Processing Engine
```python
# Correct SCS/NRCS TC Formula (TR-55):
# Step 1: Calculate lag time (hours)
L = (l^0.8 * (S + 1)^0.7) / (1900 * Y^0.5)
where:
  l = flow length (ft)
  S = (1000/CN) - 10  [retention parameter]
  Y = average watershed slope (%)
  
# Step 2: Convert lag to time of concentration
Tc = L / 0.6  [for SCS method, Tc = 1.67 * Lag]
```

### 4. DEM Processing
- **Options for slope calculation:**
  1. Zonal statistics (min/max elevation per basin)
  2. Sample along longest flow path
  3. Use centroid to outlet path
  4. Allow user to provide pre-calculated slope field

### 5. Output Generation
- **CSV with columns:**
  - Basin_ID
  - CN_Value
  - Flow_Length_ft
  - Avg_Slope_pct
  - TC_minutes
  - TC_hours
- **Shapefile:** Copy of input with TC fields added

---

## 📊 Expected Workflow

1. **User launches tool** from QGIS Python Console
2. **Selects inputs:**
   - Subbasin polygon layer
   - DEM raster layer (must be visible in dropdown!)
   - CN field (CN_Comp)
   - Basin ID field
3. **Tool processes each basin:**
   - Reads CN value from attribute
   - Calculates flow length (or reads from field)
   - Extracts slope from DEM
   - Applies SCS/NRCS formula
4. **Results displayed** in GUI table
5. **Exports results** to user-specified directory

---

## 🔧 Technical Implementation Notes

### Raster Layer Selection
```python
# Correct way to get raster layers:
from qgis.core import QgsProject, QgsRasterLayer

for layer in QgsProject.instance().mapLayers().values():
    if isinstance(layer, QgsRasterLayer):
        combo.addItem(layer.name(), layer)
```

### DEM Slope Extraction
```python
# Option 1: Zonal Statistics
result = processing.run("native:zonalstatisticsfb", {
    'INPUT': dem_layer,
    'ZONES': subbasin_layer,
    'STATISTICS': [2, 3]  # Min, Max
})

# Option 2: Sample raster at points
result = processing.run("native:rastersampling", {
    'INPUT': points_layer,
    'RASTERCOPY': dem_layer
})
```

### Proper SCS TC Calculation
```python
def calculate_tc_scs(length_ft, slope_pct, cn):
    """
    Calculate TC using SCS/NRCS TR-55 method
    """
    # Retention parameter
    S = (1000.0 / cn) - 10.0
    
    # Lag time in hours (TR-55 equation)
    lag_hours = (length_ft**0.8 * (S + 1)**0.7) / (1900 * slope_pct**0.5)
    
    # Time of concentration (Tc = Lag / 0.6)
    tc_hours = lag_hours / 0.6
    tc_minutes = tc_hours * 60
    
    return tc_minutes
```

---

## 🎓 Key References

- **SCS TR-55:** "Urban Hydrology for Small Watersheds" - Contains official TC formulas
- **NRCS NEH Part 630:** National Engineering Handbook - Hydrology chapters
- **CN Values:** Should range from 30 (good infiltration) to 98 (impervious)
- **Typical TC Range:** 5 minutes to 24 hours for most watersheds

---

## 📝 Testing Checklist

- [ ] GUI launches without errors
- [ ] Raster layers appear in DEM dropdown
- [ ] Vector layers appear in subbasin dropdown  
- [ ] Fields populate when layer selected
- [ ] CN_Comp field auto-selected if present
- [ ] Processing works for single basin
- [ ] Processing works for 100+ basins
- [ ] Progress bar updates during processing
- [ ] Results match manual calculations
- [ ] CSV export contains all data
- [ ] Shapefile export loads back into QGIS
- [ ] No hardcoded paths in code
- [ ] Works with different CRS
- [ ] Handles missing CN values gracefully
- [ ] Handles flat areas (low slope) without errors

---

## 💡 Success Criteria

The tool is successful when:
1. **It runs standalone** without requiring any patches or fixes
2. **DEM layers are visible** and selectable in the GUI
3. **TC calculations match** expected values from TR-55 manual calculations
4. **Processes 100+ basins** in under 1 minute
5. **Exports complete results** that can be used in further analysis

---

## 🚀 Next Steps for Implementation

1. **Start fresh** - Don't try to fix existing code
2. **Build GUI first** with proper raster/vector layer selection
3. **Implement correct SCS formula** per TR-55
4. **Add DEM processing** for slope extraction  
5. **Test with sample data** at known path
6. **Package as single .py file** for easy distribution

---

## 📧 Notes for Next LLM

- Read this entire document first
- The existing code in Hydro_Suite has fundamental issues - start fresh
- Focus on getting the raster layer selection working first
- Use the proper SCS/NRCS formula from TR-55, not simplified versions
- Test with the actual data file provided in the path
- Make sure everything is in one standalone script file
- The tool should work immediately when pasted into QGIS Python Console

**End Goal:** A hydrologist should be able to copy-paste one Python file into QGIS and calculate TC for hundreds of basins using their actual CN values and DEM data, with no configuration or debugging required.